//
// Created by emman on 2016/11/25.
//

#ifndef OOP_LEXER_H
#define OOP_LEXER_H

#include "syms.h"
Token_value get_token();


#endif //OOP_LEXER_H
