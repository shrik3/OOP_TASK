//
// Created by emman on 2016/11/25.
//

#ifndef OOP_PARSER_H
#define OOP_PARSER_H

double expr(bool get);
double term(bool get);
double prim (bool get);

#endif //OOP_PARSER_H
