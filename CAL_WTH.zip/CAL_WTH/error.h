//
// Created by emman on 2016/11/25.
//

#ifndef OOP_ERROR_H
#define OOP_ERROR_H

#include "syms.h"
#include <iostream>
using namespace std;

double error(const string& e);


#endif //OOP_ERROR_H
