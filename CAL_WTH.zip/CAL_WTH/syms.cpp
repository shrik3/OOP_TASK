//
// Created by emman on 2016/11/25.
//

#include "syms.h"

Token_value curr_tok ;
double number_value;
string string_value;
map<string,double> mtable;
int no_of_errors;
int curr_line=1;
int if_valid=1;